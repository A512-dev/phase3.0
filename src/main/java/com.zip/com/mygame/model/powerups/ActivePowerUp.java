// com.mygame.powerups.ActivePowerUp
package com.mygame.model.powerups;

public record ActivePowerUp(PowerUpType type, double remainingSec) { }
