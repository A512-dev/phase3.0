package com.mygame.model;

import java.util.List;

public class WorldSnapshot {
    public final List<SystemNode> nodes;


    public WorldSnapshot(List<SystemNode> nodes) {
        this.nodes = nodes;

    }
}
